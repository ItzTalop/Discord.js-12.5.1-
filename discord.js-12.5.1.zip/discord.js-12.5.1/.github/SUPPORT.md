# Seeking support?

We're sorry, we only use this issue tracker for bugs in the library itself and feature requests for it. We are not able to provide general support or answser questions on the issue tracker.

Should you want to ask such questions, please post in one of our support channels in our Discord server: https://discord.gg/bRCvFy9

Any issues that don't directly involve a bug in the library or a feature request will likely be closed and redirected to the Discord server.
